function formatTime(min) {
    const h = Math.floor(min / 60);
    const m = min % 60;
    return `${h}h ${m.toString().padStart(2, '0')}m`;
}

const container = document.getElementById('container');
const calContent = document.getElementById('calendar-content');

function createRow(name, value = 0, max = 60) {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
        <div class="card-header">
            <span class="label-text">${name}</span>
            <div><span class="temps">${formatTime(value)}</span> <button class="btn-del-row">×</button></div>
        </div>
        <input type="range" min="0" max="${max}" value="${value}">
    `;

    const slider = card.querySelector('input');
    const display = card.querySelector('.temps');

    slider.oninput = () => {
        display.innerText = formatTime(slider.value);
        if (parseInt(slider.value) >= parseInt(slider.max)) {
            checkGoal(name);
        }
        saveAll();
    };

    card.querySelector('.btn-del-row').onclick = () => { 
        card.remove(); 
        saveAll(); 
    };
    container.appendChild(card);
}

function checkGoal(name) {
    const today = new Date().toLocaleDateString();
    let history = JSON.parse(localStorage.getItem('my_history') || "[]");
    if (!history.find(h => h.date === today && h.name === name)) {
        history.push({ date: today, name: name });
        localStorage.setItem('my_history', JSON.stringify(history));
        renderCalendar();
    }
}

function renderCalendar() {
    const history = JSON.parse(localStorage.getItem('my_history') || "[]");
    calContent.innerHTML = history.length ? "" : "Aucun succès.";
    history.slice().reverse().forEach((h, index) => {
        const realIndex = history.length - 1 - index;
        const row = document.createElement('div');
        row.className = 'day-check';
        row.innerHTML = `
            <span>${h.date} - <b>${h.name}</b></span> 
            <button class="btn-del-hist" style="background:none; border:none; color:red; cursor:pointer;">×</button>
        `;
        row.querySelector('.btn-del-hist').onclick = () => {
            let hist = JSON.parse(localStorage.getItem('my_history'));
            hist.splice(realIndex, 1);
            localStorage.setItem('my_history', JSON.stringify(hist));
            renderCalendar();
        };
        calContent.appendChild(row);
    });
}

function saveAll() {
    const data = Array.from(document.querySelectorAll('.card')).map(card => ({
        name: card.querySelector('.label-text').innerText,
        value: card.querySelector('input').value,
        max: card.querySelector('input').max
    }));
    localStorage.setItem('my_time_data', JSON.stringify(data));
}

function loadAll() {
    container.innerHTML = "";
    const saved = JSON.parse(localStorage.getItem('my_time_data') || "[]");
    if (saved.length > 0) {
        saved.forEach(item => createRow(item.name, item.value, item.max));
    } else {
        // RECRÉATION DES LIGNES DE BASE SI VIDE
        createRow('Lire', 0, 150);
        createRow('Info', 0, 150);
        createRow('Cours', 0, 150);
        saveAll();
    }
    renderCalendar();
}

document.getElementById('add-btn').onclick = () => {
    const name = document.getElementById('new-name').value || "Activité";
    const max = document.getElementById('max-duration').value || 60;
    createRow(name, 0, max);
    saveAll();
    document.getElementById('new-name').value = "";
};

document.getElementById('toggle-cal').onclick = () => {
    const view = document.getElementById('calendar-view');
    view.style.display = (view.style.display === "block") ? "none" : "block";
};

document.getElementById('reset-btn').onclick = () => {
    if(confirm("Voulez-vous tout remettre à zéro ?")) {
        localStorage.clear();
        loadAll();
    }
};

document.addEventListener('DOMContentLoaded', loadAll);